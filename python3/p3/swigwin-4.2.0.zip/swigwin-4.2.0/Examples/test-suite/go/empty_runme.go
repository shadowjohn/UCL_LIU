package main

import _ "swigtests/empty"

func main() {
}
