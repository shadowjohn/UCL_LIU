
int multiply50(int a);

