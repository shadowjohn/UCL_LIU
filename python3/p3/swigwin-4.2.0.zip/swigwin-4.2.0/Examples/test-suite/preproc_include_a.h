
int multiply10(int a);

