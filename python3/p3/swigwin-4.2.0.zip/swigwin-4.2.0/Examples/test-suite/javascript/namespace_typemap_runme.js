var namespace_typemap = require("namespace_typemap");

if (namespace_typemap.stest1("hello") != "hello") {
    throw new Error;
}

if (namespace_typemap.stest2("hello") != "hello") {
    throw new Error;
}

if (namespace_typemap.stest3("hello") != "hello") {
    throw new Error;
}

if (namespace_typemap.stest4("hello") != "hello") {
    throw new Error;
}

if (namespace_typemap.stest5("hello") != "hello") {
    throw new Error;
}

if (namespace_typemap.stest6("hello") != "hello") {
    throw new Error;
}

if (namespace_typemap.stest7("hello") != "hello") {
    throw new Error;
}

if (namespace_typemap.stest8("hello") != "hello") {
    throw new Error;
}

if (namespace_typemap.stest9("hello") != "hello") {
    throw new Error;
}

if (namespace_typemap.stest10("hello") != "hello") {
    throw new Error;
}

if (namespace_typemap.stest11("hello") != "hello") {
    throw new Error;
}

if (namespace_typemap.stest12("hello") != "hello") {
    throw new Error;
}
