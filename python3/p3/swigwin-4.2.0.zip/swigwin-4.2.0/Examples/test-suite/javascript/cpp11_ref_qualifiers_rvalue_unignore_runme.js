var cpp11_ref_qualifiers_rvalue_unignore = require("cpp11_ref_qualifiers_rvalue_unignore");

new cpp11_ref_qualifiers_rvalue_unignore.RefQualifier().m1();
new cpp11_ref_qualifiers_rvalue_unignore.RefQualifier().m2();
