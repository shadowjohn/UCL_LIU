var extend_variable = require("extend_variable");

if (extend_variable.Foo.Bar != 42) {
    throw new Error;
}
