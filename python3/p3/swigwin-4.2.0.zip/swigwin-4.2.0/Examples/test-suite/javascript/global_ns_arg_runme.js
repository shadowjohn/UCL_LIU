var global_ns_arg = require("global_ns_arg");

a = global_ns_arg.foo(1);
b = global_ns_arg.bar_fn();
