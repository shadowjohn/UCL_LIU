var rename_strip_encoder = require("rename_strip_encoder");

s = new rename_strip_encoder.SomeWidget();
a = new rename_strip_encoder.AnotherWidget();
a.DoSomething();
