var template_class_reuse_name = require("template_class_reuse_name");

new template_class_reuse_name.Bool1().tt()
new template_class_reuse_name.Bool1False().ff()

new template_class_reuse_name.Bool2().tt()
new template_class_reuse_name.Bool2False().ff()

new template_class_reuse_name.Bool3().tt()
new template_class_reuse_name.Bool3False().ff()

new template_class_reuse_name.Bool4().tt()
new template_class_reuse_name.Bool4False().ff()


new template_class_reuse_name.BoolForward1().tt()
new template_class_reuse_name.BoolForward1False().ff()

new template_class_reuse_name.BoolForward2().tt()
new template_class_reuse_name.BoolForward2False().ff()

new template_class_reuse_name.BoolForward3().tt()
new template_class_reuse_name.BoolForward3False().ff()

new template_class_reuse_name.BoolForward4().tt()
new template_class_reuse_name.BoolForward4False().ff()


new template_class_reuse_name.IntBool1().tt()
new template_class_reuse_name.IntBool1False().ff()

new template_class_reuse_name.IntBool2().tt()
new template_class_reuse_name.IntBool2False().ff()

new template_class_reuse_name.IntBool3().tt()
new template_class_reuse_name.IntBool3False().ff()

new template_class_reuse_name.IntBool4().tt()
new template_class_reuse_name.IntBool4False().ff()

new template_class_reuse_name.Duplicate2_0().n()
new template_class_reuse_name.Duplicate3().n()
