var rename_rstrip_encoder = require("rename_rstrip_encoder");

s = new rename_rstrip_encoder.SomeThing();
a = new rename_rstrip_encoder.AnotherThing();
a.DoClsX();
