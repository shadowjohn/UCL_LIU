var keyword_rename = require("keyword_rename")
keyword_rename._instanceof(1)
keyword_rename._finally(1)
